package com.example.smarty_chatbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
